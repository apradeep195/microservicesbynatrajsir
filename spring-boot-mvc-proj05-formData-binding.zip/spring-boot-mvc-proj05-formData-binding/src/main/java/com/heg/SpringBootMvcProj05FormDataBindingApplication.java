package com.heg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcProj05FormDataBindingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcProj05FormDataBindingApplication.class, args);
	}

}
