package com.heg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcProj05FormDataBindingApplicationTests {

	@Test
	void contextLoads() {
	}

}
