package com.heg.string;

public class ReverseEachWord {
	
	static void reverseWord(String inputString) {
		
		String[] words= inputString.split(" ");
		String reverseString="";
		
		for(int i=0;i<words.length;i++) {
			String word=words[i];
			String reverseWord="";
			
			
		}
		
		
		
		
	}
	
	public static void main(String[] args) {
		String inputString="Java J2EE JSP Servlets Hibernate Struts";
		reverseWord(inputString);
		
		}
	}


