package com.heg.string;

public class ReverseStringWay2 {
	
	public static void main(String[] args) {
		String str="pradeep";
		//System.out.println(str.length());
		char[] ch= str.toCharArray();
		for(int i=str.length()-1;i>=0;i--) {
		//	System.out.println(i);
			System.out.print(ch[i] +"_" +i);
		}
	}

}
