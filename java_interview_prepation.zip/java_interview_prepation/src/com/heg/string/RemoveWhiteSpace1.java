package com.heg.string;

//Remove white space using inbuild function of java programming 
public class RemoveWhiteSpace1 {

	public static void main(String[] args) {

		String str="Hello Pradeep How Are You ?";
		/*
		  String str="Hello Pradeep How Are You ?";
		  String str2= str.replaceAll(" ",
		  ""); String str3=str.replaceAll("\\s", ""); System.out.println(str2);
		  System.out.println(str3);
		  
		 */
		System.out.println("====================WAY2========================");

		char[] ch = str.toCharArray();

		String withouSpace = "";
		int count = 0;
		for (int i = 0; i < str.length(); i++) {

			if ((str.charAt(i) != ' ') && (str.charAt(i) != '\t')) {
				withouSpace = withouSpace + ch[i];

			} else {
				count++;
			}

		}
		System.out.println(withouSpace);
		System.out.println(count);

		/*
		  System.out.println("====================WAY3========================");
		  System.out.println("==============COUNT SPECIAL COUNT===============");
		  
		  String specialChar="Hello@#$%PRADEEP"; String wtStr2=""; int count2=0;
		  for(int i=0;i<specialChar.length();i++) { if(
		  !Character.isDigit(specialChar.charAt(i)) &&
		  !Character.isLetter(specialChar.charAt(i)) &&
		  !Character.isLetter(specialChar.charAt(i)) ) count2++; else
		  wtStr2=wtStr2+specialChar.charAt(i); }
		  
		  System.out.println(" =======count2 ========= " +count2);
		  System.out.println(" ============wtStr2===========" +wtStr2);
		 */

	}
}
