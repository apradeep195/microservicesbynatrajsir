package com.heg.string;

public class ReverseStringWay1 {
	public static void main(String[] args) {
		String str="helloworld";
		StringBuffer sb=new StringBuffer(str);
		System.out.println(sb.reverse());
	}

}
