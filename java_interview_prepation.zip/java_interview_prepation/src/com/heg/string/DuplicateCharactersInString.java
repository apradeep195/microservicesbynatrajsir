package com.heg.string;

import java.util.HashMap;
import java.util.Set;

public class DuplicateCharactersInString {

	static void duplicatCharCount(String str) {
	
		//Creating a HashMap containing char as key and it's occurrences as value
		HashMap<Character, Integer> charCountMap = new HashMap<Character, Integer>();
		
		
		//converting given string into char array 
		char[] strArray = str.toCharArray();
		
		//checking each char of str array 
		
		for(char c : strArray) {
			
			if(charCountMap.containsKey(c)) {
				charCountMap.put(c,charCountMap.get(c)+1);
			}else {
				charCountMap.put(c, 1);
			}
		}
		
		//Getting a set containing all keys of char count Map
		
		Set<Character> charString= charCountMap.keySet();
		System.out.println("Duplicate Characte in " +str);
		
		//Iterating through set car in String 
		
		for(Character ch : charString) {
			if(charCountMap.get(ch)>1) {
				System.out.println(ch + " : " +charCountMap.get(ch));
			}
			
		//	System.out.println(ch + " : " +charCountMap.get(ch));
		}
		
		
	}
	public static void main(String[] args) {
		duplicatCharCount("Fresh Fish");
	}
}
