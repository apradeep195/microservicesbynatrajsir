package com.heg.string;

public class ReverseStringRecursion {
	
	static String recursionMethod(String str) {
		
		if((str==null) || (str.length()<=1)) {
			return str;
		}
		
		
		return recursionMethod(str.substring(1)) + str.charAt(0);
	}
	
	public static void main(String[] args) {
		
	//	System.out.println(recursionMethod("pradeep"));
		
		String m="pradeep";
		System.out.println(m.substring(1)) ;
		System.out.println(m.charAt(0));
		
		
	}

}
