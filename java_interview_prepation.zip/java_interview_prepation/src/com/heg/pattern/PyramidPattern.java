package com.heg.pattern;

public class PyramidPattern {

	public static void main(String[] args) {

		int n = 5;

		for (int i = 0; i <= n; i++) {
			for (int j = i; j <= n; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("=========================OPOSITE=========");
		
		for (int i = 0; i <= n; i++) {
			for (int j = i; j <= n; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}

}
