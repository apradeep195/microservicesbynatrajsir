package com.heg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfullSpringBootProj04JsonToObjectUsingrequestbodyApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfullSpringBootProj04JsonToObjectUsingrequestbodyApplication.class, args);
	}

}
