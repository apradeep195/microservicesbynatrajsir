package com.heg.sender;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.Session;

@Component
public class ActiveMqMessageSenderRunner {

	@Autowired
	private JmsTemplate template;
	
	
	@Scheduled(cron = "*/10 * * * * *")
	public void sendMessage()  {
		
	/*	//Using anonymouns inner class logic
		template.send("testmq1",new MessageCreator() {
			
			@Override
			public Message createMessage(Session ses) throws JMSException {
			Message message=	ses.createTextMessage("From Sender at :: " +new Date())
				return message;
			}
		});
*/
		
		
	/*
	 * USING LAMBDA STYLE ANNONYMOUNS STYLE
	 * 	template.send("testmq1", ses->{
			return ses.createTextMessage("From sender at " +new Date());
		});
		
		*/
		
		
		template.send("testmq1", ses->ses.createTextMessage("from sender at :: " +new Date()));
		
		System.out.println("==========MESSAGE HAS BEEN SEND=====");
		
	}

}
